#!/bin/bash

# Script để tắt và dọn dẹp môi trường XDP một cách toàn diện.
# Nó sẽ gỡ chương trình, xóa file ghim của chương trình và TẤT CẢ các map liên quan.

set -e

cat <(crontab -l) | sed "/cleanup_maps/d" | crontab -
if $(cat /etc/*release | grep -q "Ubuntu"); then
  systemctl restart cron
else
  systemctl restart crond
fi

# --- CẤU HÌNH ---
IFACE="eth0" # <--- Tên card mạng của bạn

BPF_FS_PATH="/sys/fs/bpf"

# Danh sách TẤT CẢ các file ghim mà hệ thống của bạn tạo ra
PINNED_FILES=(
  "xdp_ddos_prog"
  "whitelist_map"
  "log_blacklist"
  "rl_blacklist"
  "rl_counters"
)

echo "--- Bắt đầu quá trình tắt và dọn dẹp XDP toàn diện ---"

# --- BƯỚC 1: GỠ CHƯƠNG TRÌNH KHỎI CARD MẠNG ---
echo "-> Bước 1: Gỡ chương trình XDP khỏi card mạng ${IFACE}..."
if ip link show dev "$IFACE" | grep -q "xdp"; then
  sudo /usr/sbin/bpftool net detach xdp dev "$IFACE"
  echo "   ✅ Đã gỡ thành công."
else
  echo "   ℹ️ Không có chương trình XDP nào đang được gắn. Bỏ qua."
fi

# --- BƯỚC 2: XÓA TẤT CẢ CÁC FILE GHIM LIÊN QUAN ---
echo "-> Bước 2: Xóa các file ghim để giải phóng map..."
for pin_name in "${PINNED_FILES[@]}"; do
  pin_path="${BPF_FS_PATH}/${pin_name}"
  if [ -f "$pin_path" ]; then
    sudo rm -f "$pin_path"
    echo "   ✅ Đã xóa file ghim: ${pin_path}"
  fi
done

echo ""
echo "✅ Quá trình tắt và dọn dẹp hoàn tất!"

# --- BƯỚC 3: KIỂM TRA LẠI ---
echo "--- Trạng thái cuối cùng ---"
# Chờ một chút để kernel dọn dẹp
sleep 2
remaining_maps=$(sudo bpftool map list)

if [ -z "$remaining_maps" ]; then
  echo "Trạng thái map: ✅ Tất cả các map đã được dọn dẹp thành công."
else
  echo "Trạng thái map: ⚠️ Vẫn còn map tồn tại. Hãy thử reboot để xóa triệt để."
  sudo bpftool map list
fi
