#!/bin/bash

# Script để bật XDP một cách an toàn.
# Nó sẽ kiểm tra xem chương trình đã được ghim hay chưa trước khi nạp lại,
# để tránh tạo ra các map trùng lặp.

set -e

# --- CẤU HÌNH ---
IFACE="eth0" # <--- Tên card mạng của bạn
XDP_PROG_PATH="/etc/wptt/bao-mat/nftables/xdp/xdp_ddos_protection.o"
PIN_PATH="/sys/fs/bpf/xdp_ddos_prog"

echo "--- Bắt đầu quá trình kích hoạt XDP an toàn ---"

# --- LOGIC KIỂM TRA ---
# Kiểm tra xem file ghim của chương trình đã tồn tại hay chưa.
if [ -f "$PIN_PATH" ]; then
  echo "✅ Chương trình XDP đã được nạp và ghim sẵn tại ${PIN_PATH}."
  echo "-> Kiểm tra xem nó đã được gắn vào card mạng ${IFACE} chưa..."

  if ! ip link show dev "$IFACE" | grep -q "xdp"; then
    echo "   -> Chương trình chưa được gắn. Đang tiến hành gắn..."
    sudo /usr/sbin/bpftool net attach xdp pinned "$PIN_PATH" dev "$IFACE"
    echo "   ✅ Đã gắn thành công."
  else
    echo "   ✅ Chương trình đã được gắn sẵn. Không cần làm gì thêm."
  fi

  echo "--- Hoàn tất! ---"
  return 2>/dev/null
  exit 0
fi

# --- LOGIC CÀI ĐẶT (chỉ chạy khi file ghim không tồn tại) ---
echo "ℹ️ Không tìm thấy chương trình XDP đã ghim. Bắt đầu quá trình nạp mới..."

# 1. Đảm bảo BPF filesystem đã được mount
echo "-> Bước 1: Đảm bảo BPF filesystem sẵn sàng..."
sudo /bin/bash -c 'mkdir -p /sys/fs/bpf && mount -t bpf bpf /sys/fs/bpf'

# 2. Nạp và ghim chương trình
echo "-> Bước 2: Nạp chương trình XDP và tạo map..."
sudo /usr/sbin/bpftool prog load "$XDP_PROG_PATH" "$PIN_PATH"

# 3. Gắn chương trình vào card mạng
echo "-> Bước 3: Gắn chương trình vào card mạng ${IFACE}..."
sudo /usr/sbin/bpftool net attach xdp pinned "$PIN_PATH" dev "$IFACE"

cat <(crontab -l) | sed "/cleanup_maps/d" | crontab -
# cat <(crontab -l) <(echo '*/5 * * * * /root/cleanup_maps >/dev/null 2>&1') | crontab -
cat <(crontab -l) <(echo '*/5 * * * * /etc/xdp-protection/cleanup_maps > /var/log/bpf_cleanup.log 2>&1') | crontab -

if $(cat /etc/*release | grep -q "Ubuntu"); then
  systemctl restart cron
else
  systemctl restart crond
fi

echo ""
echo "✅ Cài đặt và kích hoạt XDP thành công!"
