#!/bin/bash
systemctl restart nftables

