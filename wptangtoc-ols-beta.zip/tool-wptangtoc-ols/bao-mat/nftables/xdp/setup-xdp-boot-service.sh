#!/bin/bash

# Script để tạo và kích hoạt một service systemd,
# đảm bảo chương trình XDP được nạp tự động mỗi khi máy chủ khởi động.

set -e

# --- CẤU HÌNH ---
# Vui lòng thay đổi các giá trị sau cho phù hợp với hệ thống của bạn.

# 1. Tên card mạng chính của bạn (kiểm tra bằng lệnh `ip a`)
IFACE="eth0"

# 2. Đường dẫn đầy đủ đến file XDP đã được biên dịch (.o)
XDP_PROG_PATH="/etc/wptt/bao-mat/nftables/xdp/xdp_ddos_protection.o"

# 3. Tên và đường dẫn của service sẽ được tạo
SERVICE_NAME="load-xdp.service"
SERVICE_PATH="/etc/systemd/system/${SERVICE_NAME}"

# --- LOGIC CHÍNH ---

# Kiểm tra quyền root
if [ "$EUID" -ne 0 ]; then
  echo "Lỗi: Vui lòng chạy script này với quyền root (sudo)."
  exit 1
fi

# Kiểm tra xem file XDP có tồn tại không
if [ ! -f "$XDP_PROG_PATH" ]; then
  echo "Lỗi: Không tìm thấy file chương trình XDP tại: $XDP_PROG_PATH"
  echo "Vui lòng kiểm tra lại biến XDP_PROG_PATH."
  exit 1
fi

echo "--- Bắt đầu tạo service '${SERVICE_NAME}' ---"

# Sử dụng tee để ghi nội dung vào file service với quyền root
tee "$SERVICE_PATH" <<EOF
[Unit]
Description=Load XDP DDoS Protection Program at Boot
# Chạy sau khi mạng đã sẵn sàng để đảm bảo card mạng tồn tại
After=network-online.target
Wants=network-online.target

[Service]
# Type=oneshot: Chạy các lệnh một lần rồi thoát
Type=oneshot
RemainAfterExit=yes

# Các lệnh được chạy tuần tự khi service khởi động
# Bước 1: Đảm bảo BPF filesystem đã được mount
ExecStartPre=/bin/mkdir -p /sys/fs/bpf
ExecStartPre=/bin/mount -t bpf bpf /sys/fs/bpf

# Bước 2: Nạp chương trình XDP vào kernel, việc này sẽ tự động tạo lại các BPF map
ExecStart=/usr/sbin/bpftool prog load ${XDP_PROG_PATH} /sys/fs/bpf/xdp_ddos_prog

# Bước 3: Luôn gỡ chương trình cũ trước khi gắn (để tránh lỗi "already attached")
# "|| true" để lệnh không báo lỗi nếu không có gì để gỡ.
ExecStart=/usr/sbin/bpftool net detach xdp dev ${IFACE} || true

# Bước 4: Gắn chương trình đã được nạp vào card mạng
ExecStart=/usr/sbin/bpftool net attach xdp pinned /sys/fs/bpf/xdp_ddos_prog dev ${IFACE}

# Lệnh sẽ chạy khi bạn stop service này
# Dấu "-" ở đầu để systemd bỏ qua lỗi nếu không có gì để gỡ.
ExecStop=-/usr/sbin/bpftool net detach xdp dev ${IFACE}

[Install]
# Cài đặt service để chạy ở target multi-user (chế độ server thông thường)
WantedBy=multi-user.target
EOF

echo "✅ Đã tạo thành công file service tại ${SERVICE_PATH}"

# Tải lại cấu hình của systemd, kích hoạt và khởi chạy service
echo "--- Đang kích hoạt và khởi chạy service ---"
sudo systemctl daemon-reload
sudo systemctl enable "${SERVICE_NAME}"
sudo systemctl restart "${SERVICE_NAME}"

# Kiểm tra trạng thái cuối cùng
echo "--- Kiểm tra trạng thái service ---"
# Dùng --no-pager để hiển thị toàn bộ output mà không cần cuộn
sudo systemctl status --no-pager "${SERVICE_NAME}"

echo ""
echo "✅ Hoàn tất! Service '${SERVICE_NAME}' đã được cài đặt và sẽ tự động chạy mỗi khi máy chủ khởi động."
