#!/bin/bash

# 1. Đóng gói dòng cũ số 1 (Đã cập nhật chuẩn xác theo mẫu mới của sếp)
read -r -d '' OLD_CODE_1 << 'BLOCK_1'
for entry in $(ls -A /etc/wptt/vhost | grep -v '^\.\.conf$' | sort -uV); do
BLOCK_1
OLD_CODE_1="${OLD_CODE_1%$'\n'}"

# 2. Đóng gói dòng cũ số 2 (Đã cập nhật regex sed mới)
read -r -d '' OLD_CODE_2 << 'BLOCK_2'
domain=$(echo "$entry" | sed 's/^\.//' | sed 's/\.conf$//')
BLOCK_2
OLD_CODE_2="${OLD_CODE_2%$'\n'}"

# 3. Đóng gói toàn bộ vòng lặp mới siêu sạch
read -r -d '' NEW_CODE << 'BLOCK_NEW'
	for filepath in /etc/wptt/vhost/.*.conf; do
		[[ ! -f "$filepath" || "$filepath" == *"/..conf" ]] && continue

		domain="${filepath##*/}" #cắt hết / ở phía truớc chỉ dữ giá trị / ở sau còn dữ lại như: .wptangtoc.com.conf
		domain="${domain%.conf}" #cắt .conf ở phía sau => còn: .wptangtoc.com
		domain="${domain#.}" #cắt . ở phía truớc => còn wptangtoc.com

		if [[ "$domain" != ?*.?* ]]; then #yêu cầu phải có dấu . trong domain thì mới gọi là domain đúng, nếu không có . thì continue nhảy qua for 
			continue
		fi
BLOCK_NEW
NEW_CODE="${NEW_CODE%$'\n'}"

export OLD_CODE_1 OLD_CODE_2 NEW_CODE

# 4. Thi triển càn quét bằng Perl (Dùng \h* để bắt mọi loại khoảng trắng ẩn/Tab)
find . -type f -exec perl -0777 -pi -e 's/^\h*\Q$ENV{OLD_CODE_1}\E\r?\n\h*\Q$ENV{OLD_CODE_2}\E/$ENV{NEW_CODE}/gm' {} +

echo -e "\n✅ Càn quét thay máu hoàn tất! Sếp gõ 'git diff' để nghiệm thu nhé."
