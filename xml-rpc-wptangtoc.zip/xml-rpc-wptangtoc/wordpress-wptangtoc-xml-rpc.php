<?php
/**
 * Plugin Name: Tắt XML-RPC WordPress (WPTangToc)
 * Plugin URI:  https://wptangtoc.com
 * Description: Vô hiệu hóa toàn diện XML-RPC, Pingback/Trackback và loại bỏ các header/thẻ khai báo liên quan. Phát triển bởi WPTangToc OLS.
 * Version:     2.0.0
 * Requires at least: 5.0
 * Requires PHP: 7.3
 * Author:      Gia Tuấn
 * Author URI:  https://wptangtoc.com
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: xml-rpc-wptangtoc
 * Update URI:  false
 */

// Chặn truy cập trực tiếp vào file plugin (chống lộ đường dẫn & thực thi ngoài ngữ cảnh WordPress)
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPTangToc_Disable_XMLRPC', false ) ) {

	final class WPTangToc_Disable_XMLRPC {

		/**
		 * Khởi tạo toàn bộ lớp phòng vệ XML-RPC ở tầng ứng dụng.
		 *
		 * @return void
		 */
		public static function init() {
			// 1. Chốt chặn sớm nhất nếu request đi thẳng vào xmlrpc.php (phòng trường hợp chưa chặn ở .htaccess)
			self::maybe_block_xmlrpc_request();

			// 2. Vô hiệu hóa hoàn toàn các phương thức XML-RPC (cả có xác thực lẫn không xác thực)
			add_filter( 'xmlrpc_enabled', '__return_false', PHP_INT_MAX );
			add_filter( 'xmlrpc_methods', '__return_empty_array', PHP_INT_MAX );

			// 3. Khóa tùy chọn XML-RPC legacy (tương thích ngược các plugin kiểm tra option cũ)
			add_filter( 'pre_option_enable_xmlrpc', '__return_zero', PHP_INT_MAX );
			add_filter( 'pre_update_option_enable_xmlrpc', '__return_false', PHP_INT_MAX );

			// 4. Tắt hoàn toàn Pingback & Trackback
			add_filter( 'pings_open', '__return_false', PHP_INT_MAX );
			add_filter( 'wp_headers', array( __CLASS__, 'remove_x_pingback_header' ), PHP_INT_MAX );
			add_filter( 'bloginfo_url', array( __CLASS__, 'filter_pingback_url' ), PHP_INT_MAX, 2 );

			// 5. Gỡ bỏ các thẻ khai báo XML-RPC/RSD/WLW trong HTML <head>
			add_action( 'init', array( __CLASS__, 'cleanup_discovery_links' ), 20 );

			// 6. Chỉ nạp liên kết hỗ trợ trong màn hình quản trị để không tốn tài nguyên Front-end
			if ( is_admin() ) {
				add_filter(
					'plugin_action_links_' . plugin_basename( __FILE__ ),
					array( __CLASS__, 'add_action_links' )
				);
			}
		}

		/**
		 * Ngắt sớm ngay khi phát hiện request XML-RPC trước khi WordPress nạp theme & khởi tạo IXR_Server.
		 *
		 * @return void
		 */
		private static function maybe_block_xmlrpc_request() {
			if ( ! defined( 'XMLRPC_REQUEST' ) || ! XMLRPC_REQUEST ) {
				return;
			}

			if ( defined( 'WP_CLI' ) && WP_CLI ) {
				return;
			}

			if ( ! headers_sent() ) {
				if ( function_exists( 'status_header' ) ) {
					status_header( 403 );
				} else {
					http_response_code( 403 );
				}
				header( 'Content-Type: text/plain; charset=utf-8' );
				header( 'X-Robots-Tag: noindex, nofollow', true );
				header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
			}

			exit( 'XML-RPC services đã bị tắt' );
		}

		/**
		 * Xóa header X-Pingback không phân biệt chữ hoa/thường và phòng thủ kiểu dữ liệu cho PHP 8+.
		 *
		 * @param mixed $headers Danh sách HTTP headers.
		 * @return mixed
		 */
		public static function remove_x_pingback_header( $headers ) {
			if ( ! is_array( $headers ) ) {
				return $headers;
			}

			foreach ( array_keys( $headers ) as $key ) {
				if ( is_string( $key ) && 'x-pingback' === strtolower( $key ) ) {
					unset( $headers[ $key ] );
				}
			}

			return $headers;
		}

		/**
		 * Trả về chuỗi rỗng khi theme/plugin gọi bloginfo('pingback_url').
		 *
		 * @param string $output URL đầu ra.
		 * @param string $show   Loại thông tin đang truy vấn.
		 * @return string
		 */
		public static function filter_pingback_url( $output, $show = '' ) {
			if ( 'pingback_url' === $show ) {
				return '';
			}
			return $output;
		}

		/**
		 * Gỡ các thẻ quảng bá endpoint xmlrpc.php khỏi mã nguồn HTML.
		 *
		 * @return void
		 */
		public static function cleanup_discovery_links() {
			remove_action( 'wp_head', 'rsd_link', 10 );
			remove_action( 'wp_head', 'wlwmanifest_link', 10 );
			remove_action( 'xmlrpc_rsd_apis', 'rest_output_rsd', 10 );
		}

		/**
		 * Thêm liên kết hỗ trợ trong danh sách Plugin tại WP-Admin.
		 *
		 * @param mixed $links Danh sách action links hiện tại.
		 * @return mixed
		 */
		public static function add_action_links( $links ) {
			if ( ! is_array( $links ) ) {
				return $links;
			}

			$links[] = sprintf(
				'<a href="%s" target="_blank" rel="noopener noreferrer" style="color:#b40404;font-weight:600;">%s</a>',
				esc_url( 'https://wptangtoc.com' ),
				esc_html( 'Yêu cầu hỗ trợ' )
			);

			return $links;
		}
	}

	WPTangToc_Disable_XMLRPC::init();
}
