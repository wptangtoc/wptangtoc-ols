### 🐛 Sửa lỗi
- **Khắc phục lỗi hệ thống**: Xử lý triệt để các sự cố tiềm ẩn, gia tăng độ ổn định và khả năng vận hành liên tục cho toàn bộ hệ thống máy chủ.

### 🛠️ Tối ưu hệ thống
- **Nâng cao chất lượng mã nguồn**: Bổ sung bộ kiểm định tự động (BATS tests) toàn diện, giúp kiểm soát chặt chẽ chất lượng vận hành, đảm bảo tính ổn định và an toàn tuyệt đối cho mọi tác vụ quản trị webserver.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.4.0.3

### 🛠️ Tối ưu hệ thống
- **Cải tiến hệ thống cập nhật**: Tối ưu hóa toàn diện quy trình cập nhật phần mềm, giúp quá trình nâng cấp phiên bản diễn ra mượt mà, ổn định, nhanh chóng và an toàn tuyệt đối cho máy chủ.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.4.0.2

### 🛠️ Tối ưu hệ thống
- **Cải tiến cơ chế xóa OPcache PHP**: Tối ưu hóa quy trình làm sạch bộ nhớ đệm OPcache, giúp áp dụng các thay đổi mã nguồn PHP tức thì, ngăn ngừa lỗi lưu cache cũ (stale cache) và giải phóng tài nguyên RAM hiệu quả mà không làm gián đoạn hoạt động của máy chủ web.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
## WPTangToc OLS 8.4.0.1

🛠️ Tối ưu hệ thống:
- Tối ưu hóa cơ chế tắt đồng bộ file `.htaccess` sang vhost, giúp tăng tốc độ và giảm tải đáng kể khi nạp lại (reload) LiteSpeed Web Server.

🚀 Tính năng mới & Bảo mật:
- Nâng cấp toàn diện các lớp bảo mật, giúp hệ thống phòng thủ kiên cố hơn trước các mối đe dọa và lỗ hổng tiềm ẩn.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.4.0.0

🚀 **Tính năng mới**
- **Tương thích toàn diện Apache .htaccess:** Nâng cấp cơ chế xử lý tệp `.htaccess` tương thích tuyệt đối với chuẩn Apache trên OpenLiteSpeed, đảm bảo các quy tắc định tuyến, đường dẫn tĩnh và bảo mật của WordPress hoạt động mượt mà, chính xác.
- **Cập nhật chứng chỉ Google Trust Services (GTS):** Tích hợp và cập nhật các tiêu chuẩn chứng chỉ SSL mới nhất từ Google Trust Services, gia tăng uy tín và độ tin cậy HTTPS cho website.

🛠️ **Tối ưu hệ thống**
- **Tối ưu hóa cơ chế tải lại dịch vụ (LSWS):** Cải tiến quy trình vô hiệu hóa tệp `.htaccess` và chuyển đổi Virtual Hosts, giúp quá trình reload OpenLiteSpeed diễn ra nhanh chóng, mượt mà và giảm thiểu tối đa độ trễ cho máy chủ.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.4.0.0

🚀 **Tính năng mới**
- **Tương thích toàn diện Apache .htaccess:** Nâng cấp sâu cơ chế xử lý tệp `.htaccess` tương thích tuyệt đối với chuẩn Apache trên OpenLiteSpeed, đảm bảo các quy tắc định tuyến, đường dẫn tĩnh và bảo mật của WordPress hoạt động mượt mà và chính xác hoàn toàn.
- **Cập nhật chứng chỉ Google Trust Services (GTS):** Tích hợp và cập nhật các tiêu chuẩn chứng chỉ SSL mới nhất từ Google Trust Services, mang đến sự lựa chọn bảo mật uy tín và gia tăng độ tin cậy HTTPS cho toàn bộ website.

🛠️ **Tối ưu hệ thống**
- **Tối ưu hóa cơ chế tải lại dịch vụ (LSWS):** Cải tiến quy trình vô hiệu hóa tệp `.htaccess` và chuyển đổi Virtual Hosts, giúp quá trình reload OpenLiteSpeed diễn ra nhanh chóng, mượt mà và giảm thiểu tối đa độ trễ cho máy chủ.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.4.0.0

🛠️ **Tối ưu hệ thống**
- **Tối ưu hóa cơ chế tải lại dịch vụ (LSWS):** Cải tiến quy trình vô hiệu hóa tệp `.htaccess` và chuyển đổi Virtual Hosts, giúp quá trình reload OpenLiteSpeed diễn ra nhanh chóng, mượt mà và giảm thiểu tối đa độ trễ cho máy chủ.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.4.0.0

🛠️ **Tối ưu hệ thống**
- **Tối ưu hóa cơ chế tải lại dịch vụ (LSWS):** Cải tiến quy trình vô hiệu hóa tệp `.htaccess` và chuyển đổi Virtual Hosts, giúp quá trình reload OpenLiteSpeed diễn ra nhanh chóng, mượt mà và giảm thiểu tối đa độ trễ cho máy chủ.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.4.0

🚀 **Tính năng mới & Nâng cấp bảo mật**

- **Tương thích toàn diện Apache .htaccess:** Nâng cấp sâu cơ chế xử lý tệp `.htaccess` tương thích tuyệt đối với chuẩn Apache trên OpenLiteSpeed, đảm bảo các quy tắc định tuyến, đường dẫn tĩnh và bảo mật của WordPress hoạt động mượt mà, chính xác hoàn toàn.
- **Cập nhật chứng chỉ Google Trust Services (GTS):** Tích hợp và cập nhật các tiêu chuẩn chứng chỉ SSL mới nhất từ Google Trust Services, mang đến sự lựa chọn bảo mật uy tín và gia tăng độ tin cậy HTTPS cho toàn bộ website.

---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS v8.3.4.0

🚀 **Tính năng mới & Nâng cấp bảo mật**

* **Bổ sung chứng chỉ SSL Google Trust Services:** Mở rộng thêm lựa chọn nhà cung cấp chứng chỉ SSL uy tín, giúp quản trị viên dễ dàng tăng cường bảo mật cho website.
* **Hỗ trợ chuẩn mã hóa kháng lượng tử:** Nâng cấp hệ thống sẵn sàng với các tiêu chuẩn bảo mật kháng lượng tử (Quantum-Resistant) đón đầu công nghệ tương lai.
* **Cài đặt ZeroSSL 1 chạm:** Đơn giản hóa toàn bộ quy trình thiết lập chứng chỉ ZeroSSL với cơ chế cài đặt một chạm nhanh chóng, thuận tiện như Let's Encrypt.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.3.4

🚀 **Tính năng mới**
- **Tự động gia hạn chứng chỉ SSL trả phí:** Bổ sung tính năng tự động hóa hoàn toàn quy trình gia hạn chứng chỉ SSL trả phí, giúp quản trị viên loại bỏ hoàn toàn rủi ro gián đoạn dịch vụ website do hết hạn chứng chỉ.

🛠️ **Tối ưu hệ thống**
- **Nâng cao bảo mật và trải nghiệm SSH kháng lượng tử:** Tinh chỉnh và tối ưu hóa sâu cơ chế mã hóa SSH chống lượng tử, gia tăng cường độ bảo mật tuyệt đối trước các nguy cơ công nghệ tương lai đồng thời cải thiện mượt mà trải nghiệm tương tác (UX) cho quản trị viên khi kết nối máy chủ từ xa.

---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.3.3

🚀 **Tính năng mới**
- **Bảo mật SSH chống lượng tử tiên tiến:** Tích hợp cơ chế mã hóa SSH kháng lượng tử, giúp bảo vệ tuyệt đối các kết nối quản trị từ xa trước nguy cơ tấn công và giải mã bằng công nghệ lượng tử trong tương lai, nâng cao tối đa lớp phòng thủ an ninh mạng cho máy chủ.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.3.2.4

🛠️ **Tối ưu hệ thống**
- **Cải tiến an toàn tệp cấu hình:** Nâng cấp cơ chế ghi và chỉnh sửa cấu hình hệ thống (httpd, vhost, MariaDB, PHP.ini) với tính năng bảo vệ toàn diện, đảm bảo dữ liệu không bị hỏng hóc hoặc mất mát ngay cả khi xảy ra sự cố gián đoạn nguồn điện đột ngột.
- **Kiểm tra tính hợp lệ trước khi khởi động dịch vụ:** Tự động kiểm tra kỹ lưỡng cú pháp và tính toàn vẹn của tệp cấu hình trước khi tiến hành khởi động lại các dịch vụ, giúp ngăn chặn triệt để tình trạng lỗi downtime hệ thống do cấu hình không hợp lệ.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
🛠️ Tối ưu hệ thống
- Nâng cấp công cụ giám sát tài nguyên `wtop` giúp theo dõi hệ thống trực quan và chính xác hơn.
- Cải thiện quy trình chuyển đổi phiên bản PHP, giúp thao tác mượt mà, nhanh chóng và ổn định hơn.
- Tối ưu hiệu năng tìm kiếm với cơ chế Debounce, giúp giảm tải tài nguyên và tăng tốc độ phản hồi cho máy chủ.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.3.2.2

🛠️ **Tối ưu hệ thống**
- **Cải tiến hiệu năng tìm kiếm:** Tích hợp cơ chế debounce giúp tối ưu hóa tốc độ phản hồi và giảm tải tài nguyên hệ thống, mang lại trải nghiệm thao tác mượt mà và chính xác hơn cho quản trị viên.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
# WPTangToc OLS 8.3.2.1

🚀 **Tính năng mới & Cải tiến**
- Tích hợp cơ chế nhân Linux chuyên sâu chống DDoS, giúp bảo vệ webserver vững chắc trước các cuộc tấn công mạng quy mô lớn.
- Tinh chỉnh trải nghiệm dòng lệnh, bổ sung cơ chế xử lý chờ thông minh cho tính năng tìm kiếm (`search wptangtoc`) giúp thao tác của quản trị viên mượt mà và chính xác ngay cả khi dữ liệu chưa tải xong.

🛠️ **Tối ưu hệ thống**
- Tối ưu hóa hiệu năng nhân Linux chuyên sâu dành riêng cho các dòng máy chủ sử dụng vi xử lý AMD Ryzen, khai thác tối đa sức mạnh phần cứng.
- Nâng cấp thuật toán cân bằng tải NUMA, giúp cải thiện hiệu suất xử lý và phân phối tài nguyên trên hệ thống phần cứng đa socket.
- Cải tiến hệ thống tường lửa `nftables` với khả năng quản lý traffic đầu ra (output) chặt chẽ và tối ưu hóa mạng lưới tốt hơn.

🐛 **Sửa lỗi**
- Khắc phục triệt để lỗi xung đột thông báo trong quá trình chạy bộ cài đặt WPTangToc OLS.
- Sửa lỗi kiểm tra phiên bản `nftables` trong mô-đun quản lý dịch vụ, đảm bảo các service vận hành ổn định không bị gián đoạn.


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
## 📌 Lịch sử cập nhật WPTangToc OLS 8.3.2.1

- 6f7c65ab Cân bằng tải NUMA tối ưu
- 4361aab5 optimize kernel linux cho wptangtoc ols


---
*Bản phát hành bao gồm toàn bộ chữ ký xác thực GPG, SHA256SUMS và Full Source Code.*
