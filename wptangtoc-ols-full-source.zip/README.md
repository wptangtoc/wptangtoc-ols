<div align="center">
    <h1>WPTangToc OLS</h1>
    <p><b>Giải pháp Thiết lập & Quản trị Webserver Miễn phí, Siêu tốc độ, Dành riêng cho WordPress</b></p>
    <p>
    <a href="https://github.com/wptangtoc/wptangtoc-ols/actions/workflows/ci.yml"><img src="https://github.com/wptangtoc/wptangtoc-ols/actions/workflows/ci.yml/badge.svg?branch=main" alt="Build & Test"></a>
    <a href="https://github.com/aquasecurity/trivy"><img src="https://img.shields.io/badge/Security_Scan-Trivy-blue.svg" alt="Trivy Security"></a>
    <a href="https://wptangtoc.com"><img src="https://img.shields.io/badge/Optimized%20for-WordPress-21759b.svg" alt="Optimized for WordPress"></a>
    <a href="https://github.com/wptangtoc/wptangtoc-ols/releases"><img src="https://img.shields.io/github/v/release/wptangtoc/wptangtoc-ols?label=stable&color=007ec6" alt="Stable Version"></a>
    <a href="https://github.com/wptangtoc/wptangtoc-ols?tab=GPL-3.0-1-ov-file"><img src="https://img.shields.io/badge/License-GPLv3-blue.svg" alt="License GPLv3"></a>
    <img src="https://img.shields.io/badge/Architecture-x86__64%20%7C%20ARM-success.svg" alt="Architecture">
    </p>
</div>

<hr>

<h2>🌟 Sứ mệnh của chúng tôi</h2>
<p>Sứ mệnh của WPTangToc OLS là mang đến một hệ sinh thái máy chủ hoàn hảo, nơi hiệu năng chạm đỉnh và bảo mật được đặt lên hàng đầu. Đây không chỉ là một Bash Script cài đặt đơn thuần, mà là kết tinh của hàng ngàn giờ tối ưu hóa chuyên sâu. Chúng tôi tập trung <b>100% nguồn lực vào mã nguồn WordPress</b>, giúp các Sysadmin từ tay ngang đến chuyên nghiệp quản trị máy chủ một cách mượt mà, nhàn nhã và mạnh mẽ nhất.</p>

<h2>🔥 Tại sao bạn nên chọn WPTangToc OLS?</h2>
<ul>
    <li>⚡ <b>Hiệu năng xé gió:</b> Tích hợp OpenLiteSpeed, LSPHP tùy biến (nhanh hơn PHP-FPM thuần), Giao thức HTTP/3 QUIC, và tối ưu Object Cache (Redis/Memcached/Valkey/KeyDB) ở mức tầng UNIX Socket sâu nhất.</li>
    <li>🛡️ <b>Bảo mật cô lập:</b> Sử dụng công nghệ <code>PhpSuExec + Chroot + Namespace</code> để giam lỏng (cô lập) từng website. Nếu một trang web trên máy chủ bị hack, hacker cũng vĩnh viễn không thể "cháy lan" sang các trang web khác. nhiều lớp giúp giảm thiểu nguy cơ lây lan mã độc giữa các website.</li>
    <li>🤖 <b>Tự động hóa thông minh:</b> Mọi thao tác cấu hình phức tạp, tối ưu Database, hay quản lý Firewall đều được giải quyết tự động chỉ bằng phím bấm.</li>
    <li>☁️ <b>Bảo vệ dữ liệu toàn diện:</b> Hệ thống sao lưu thông minh vận hành hoàn toàn tự động đóng gói và đẩy thẳng dữ liệu của bạn lên đa nền tảng Cloud (Amazon S3, Google Drive, OneDrive, Telegram, Cloudflare R2...). Giải phóng bạn khỏi nỗi lo rủi ro phần cứng, hỏng ổ cứng... Đảm bảo website luôn có sẵn phương án khôi phục thần tốc trước mọi sự cố hay thảm họa không lường trước.</li>
    <li>⚡<b>Triết lý thiết kế tối giản và nhẹ:</b> Code hoàn toàn hướng tới việc tối ưu trên môi trường CLI (dòng lệnh), không mang theo gánh nặng giao diện (GUI bloatware). Điều này giúp WPTangToc OLS tiêu tốn cực kỳ ít tài nguyên máy chủ, đồng thời thu hẹp bề mặt tấn công bảo mật so với các control panel truyền thống.</li>
    <li>✅ <b>An tâm tuyệt đối (DevSecOps):</b> Quét bảo mật tự động (Trivy, Gitleaks, ShellCheck, Semgrep) và kiểm thử khắt khe qua BATS trên đa nền tảng máy ảo CI của GitHub Actions (x86_64 & ARM64), đảm bảo sự ổn định tuyệt đối trước khi đến tay bạn.</li>
</ul>

<hr>

<h2>💻 Hệ điều hành & Cấu hình hỗ trợ</h2>

<h3>🐧 Hệ điều hành Linux (Kiến trúc x86_64 & ARM)</h3>
<ul>
    <li><b>AlmaLinux:</b> 8, 9, 10 <i>(Khuyên dùng: AlmaLinux 9)</i> 🏆</li>
    <li><b>Rocky Linux:</b> 8, 9, 10</li>
    <li><b>Red Hat Enterprise Linux (RHEL):</b> 8, 9, 10</li>
    <li><b>Oracle Linux Server:</b> 8, 9, 10</li>
    <li><b>Ubuntu:</b> 22.04, 24.04 <i>(Thử nghiệm)</i></li>
</ul>

<h3>⚙️ Cấu hình yêu cầu</h3>
<ul>
    <li><b>Tối thiểu:</b> CPU 1 vCore | RAM > 512MB | Ổ cứng > 8GB</li>
    <li><b>Khuyến nghị:</b> CPU 1 vCore | RAM > 2GB | Ổ cứng > 20GB</li>
</ul>
<p><i>💡 Lời khuyên: Nếu bạn chưa có VPS, hãy chọn các nhà cung cấp uy tín để có trải nghiệm tốt nhất với phần mềm.</i></p>

<hr>

<h2>⚡ Hướng dẫn cài đặt</h2>

<h3>Cách 1: Cài đặt tiêu chuẩn (Có tương tác)</h3>
<p>Bạn chỉ cần dán đoạn mã này vào Terminal (quyền <code>root</code>), hệ thống sẽ chạy và có menu hỏi bạn một số thiết lập cơ bản:</p>
<pre><code>curl -sO https://wptangtoc.com/share/wptangtoc-ols && bash wptangtoc-ols</code></pre>
<p><i>Link dự phòng từ GitHub:</i></p>
<pre>curl -sO https://wptangtoc.github.io/wptangtoc-ols/wptangtoc-ols && bash wptangtoc-ols</pre>

<h3>Cách 2: 🤖 Cài đặt Không Chạm (Unattended / Zero-Touch)</h3>
<p>Tuyệt chiêu dành cho các Sysadmin muốn triển khai hạ tầng hàng loạt (Mass Deployment) qua Ansible, Cloud-Init, hãng VPS đóng thành template hay Snapshots để nhân bản rất nhanh chóng và tiện lợi hoặc đơn giản là bạn "lười" bấm phím. Chỉ cần thêm cờ <code>--auto</code>, phần mềm sẽ <b>tự động bỏ qua mọi câu hỏi</b>, áp dụng ngay cấu hình mặc định an toàn, ổn định và nhanh nhất do tác giả định chuẩn (PHP 8.3, MariaDB Stable LTS 10.11, Port SSH mặc định).</p>
<pre><code>curl -sO https://wptangtoc.com/share/wptangtoc-ols && bash wptangtoc-ols --auto</code></pre>
<p><i>Link dự phòng từ GitHub:</i></p>
<pre>curl -sO https://wptangtoc.github.io/wptangtoc-ols/wptangtoc-ols && bash wptangtoc-ols --auto</pre>
<hr>


<br>
<details>
    <summary><i>🛡️ Dành cho Sysadmin: Mã SHA256 kiểm tra toàn vẹn file (Click để xem)</i></summary>
    <br>
    <blockquote>
        <code>wptangtoc-ols: <!-- SHA256_START -->56da8f4d1af9a753bc9180550f63dac6c13f4744448082de0a97b303f4d85b9b<!-- SHA256_END --></code>
    </blockquote>
</details>
<hr>

<h2>🛠️ Danh sách Tính năng Đồ sộ</h2>
<p>WPTangToc OLS không chỉ là kịch bản cài đặt, mà là một hệ sinh thái quản trị máy chủ hoàn chỉnh mang tiêu chuẩn Enterprise, bao gồm:</p>
<ul>
    <li><b>Nền tảng lõi tối thượng:</b> Vận hành trên OpenLiteSpeed, LSPHP tùy biến đa phiên bản (7.1 đến 8.5 chạy song song) và hệ quản trị cơ sở dữ liệu MariaDB LTS (10.11 đến 12.3).</li>
    <li><b>Tối ưu Hệ điều hành & Mạng (Kernel Tuning):</b> Tự động cấu hình sysctl, ulimit, kích hoạt thuật toán chống nghẽn mạng TCP BBR và phân bổ tối ưu Zram/Swap theo đúng phần cứng vật lý.</li>
    <li><b>Quản lý Website toàn diện:</b> Khởi tạo không giới hạn Domain/Subdomain, cấp phát chứng chỉ SSL Let's Encrypt hoặc ZeroSSL chỉ với 1 thao tác tự động gia hạn vĩnh viễn.</li>
    <li><b>Dễ dàng nhân bản (Clone)</b> Tạo môi trường thử nghiệm (Staging cấp sẵn miễn phí domain *.wptangtoc-ols.com để giả lập) chỉ với 1 thao tác.</li>
    <li><b>Bảo mật Cô lập (Defense in Depth):</b> Ứng dụng công nghệ PhpSuExec + Chroot + Namespace giam lỏng từng website. Chống "cháy lan" mã độc.</li>
    <li><b>Tường lửa & Quét mã độc:</b> Tích hợp 8G Firewall, CSF/Firewalld/NFtables bảo vệ. Trang bị Yara, Fail2ban chống Brute Force, Khóa IP xấu và thiết lập chặn truy cập theo Quốc gia.</li>
    <li><b>Cache Đa tầng Tiên tiến:</b> Bật sẵn OPcache, Page Cache HTML, Browser Cache. Hỗ trợ cấu hình Object Cache siêu tốc (Redis, Memcached, Valkey, KeyDB) giao tiếp trực tiếp qua UNIX Socket.</li>
    <li><b>Tối ưu chuyên sâu WordPress:</b> Hỗ trợ quản trị mạnh mẽ qua WP-CLI. Tự động thiết lập tính năng siêu bảo mật LockDown WordPress và thay thế WP-Cron bằng Linux Cron để giảm tải CPU.</li>
    <li><b>Quản trị Database Thông minh:</b> Tự động Auto-tune cấu hình MariaDB (Query Cache, Buffer Pool) khớp với lượng RAM hiện có. Tích hợp sẵn PHPMyAdmin và hỗ trợ chuyển đổi Engine (InnoDB, MyISAM, Aria).</li>
    <li><b>Tương thích Cloudflare CDN:</b> Hỗ trợ SSL full Cloudflare và show real ip Cloudflare...</li>
    <li><b>An toàn Dữ liệu & Tự động hóa:</b> Tự động sao lưu định kỳ. và đẩy thẳng lên Cloud (Amazon S3, Cloudflare R2, Google Drive, OneDrive, Telegram...).</li>
    <li><b>Giám sát & Tự phục hồi:</b> Cảnh báo đăng nhập lạ qua Telegram. Giám sát tài nguyên máy chủ (wtop) thời gian thực và tự động Restart các dịch vụ nếu phát hiện tình trạng treo, đảm bảo Uptime tối đa.</li>
    <li><b>Hỗ trợ .Htaccess Realtime Full Apache .htaccess tương thích</b></li>
    <li><b>Còn nhiều tính năng khác đợi bạn trải nghiệm...</b></li>
</ul>

<hr>

<h2>📚 Nguồn tài liệu & Cộng đồng hỗ trợ</h2>
<ul>
    <li><b>Trang chủ & Hướng dẫn chi tiết:</b> <a href="https://wptangtoc.com/wptangtoc-ols/">Tại đây</a></li>
    <li><b>Nhật ký cập nhật (Changelog) Commit:</b> <a href="https://github.com/wptangtoc/wptangtoc-ols/commits/main/">Tại đây</a></li>
    <li><b>Cộng đồng hỗ trợ:</b> Tham gia <a href="https://www.facebook.com/groups/wptangtoc/">Group Tăng Tốc WordPress</a> trên Facebook để được giải đáp thắc mắc.</li>
</ul>

<h3>Các lõi công nghệ & Mã nguồn mở được tích hợp:</h3>
<p>
    <a href="https://openlitespeed.org/">OpenLiteSpeed</a> | 
    <a href="https://downloads.mariadb.org/">MariaDB</a> | 
    <a href="https://www.php.net/">PHP</a> | 
    <a href="https://wordpress.org/">WordPress</a> | 
    <a href="https://wp-cli.org/">WP-CLI</a> | 
    <a href="https://rclone.org/">Rclone</a> | 
    <a href="https://www.fail2ban.org/">Fail2ban</a> | 
    <a href="https://www.phpmyadmin.net/">phpMyAdmin</a> | 
    <a href="https://letsencrypt.org/">Let's Encrypt</a> | 
    <a href="https://valkey.io/">Valkey</a> | 
    <a href="https://virustotal.github.io/yara/">Yara</a> | 
    <a href="https://tinyfilemanager.github.io/">TinyFileManager</a> |
    <a href="https://perishablepress.com/8g-firewall/">8G Firewall</a> |
    <a href="https://aquasecurity.github.io/trivy/">Aqua Trivy (Bảo mật)</a> |
    <a href="https://github.com/gitleaks/gitleaks">Gitleaks</a> |
    <a href="https://www.shellcheck.net/">ShellCheck</a> |
<a href="https://semgrep.dev/">Semgrep (SAST)</a>
</p>


<h2>🛡️ Sẵn sàng Kháng Lượng Tử (Post-Quantum Cryptography - PQC Ready)</h2>
WPTangToc OLS tự hào là một trong những script quản trị máy chủ đi tiên phong trong việc tích hợp và mặc định kích hoạt tiêu chuẩn bảo mật của tương lai, bảo vệ hệ thống khỏi các cuộc tấn công giải mã từ siêu máy tính lượng tử (Store Now, Decrypt Later):

*   **Bảo mật Web (HTTPS):** Tích hợp sẵn core OpenLiteSpeed với thư viện BoringSSL mới nhất, tự động kích hoạt cơ chế đàm phán khóa lai hậu lượng tử (Hybrid Post-Quantum Key Exchange - thuật toán Kyber / ML-KEM).
*   **Bảo mật Kết nối (SSH):** Cấu hình SSH Hardening áp dụng các thuật toán trao đổi khóa kháng lượng tử hiện đại nhất (như `mlkem768x25519 và sntrup761x25519`), đảm bảo đường truyền quản trị tới máy chủ không thể bị bẻ khóa trong tương lai.

<hr>

<h2>🤝 Ủng hộ tác giả (Donate)</h2>
<p>Phần mềm này là tâm huyết được phát triển hoàn toàn miễn phí và sẽ luôn như vậy. Dù vậy, bánh mì trên bàn thì không miễn phí. Nếu công cụ này giúp bạn tiết kiệm thời gian, bảo vệ máy chủ an toàn và mang lại doanh thu tốt, hãy tiếp thêm động lực (và bánh mì) để tác giả tiếp tục nâng cấp dự án nhé:</p>
<p>👉 <b><a href="https://wptangtoc.com/donate">Tài trợ tặng bánh mì cho tác giả tại đây</a></b></p>

<hr>

<h2>📞 Liên hệ & Tác giả</h2>
<ul>
    <li><b>Người phát triển:</b> <a href="https://wptangtoc.com/gia-tuan/">Gia Tuấn</a> và cộng đồng Tăng Tốc WordPress.</li>
    <li><b>Email:</b> <a href="mailto:giatuan@wptangtoc.com">giatuan@wptangtoc.com</a></li>
    <li><b>Hotline/Zalo:</b> 0866.880.462</li>
</ul>

<hr>

<h2>🔒 Cam kết Quyền riêng tư & Minh bạch (Zero Telemetry)</h2>
<p>Chúng mình thấu hiểu rằng đối với System Admin, dữ liệu và quyền kiểm soát là ranh giới không thể xâm phạm. WPTangToc OLS được xây dựng dựa trên triết lý tối thượng đó:</p>
<ul>
    <li>📖 <b>100% Minh bạch (Transparent):</b> Toàn bộ mã nguồn bash script đều là mã thuần (clear-text), không mã hóa (no obfuscation), không biên dịch ẩn. Bất kỳ ai cũng có thể (và được khuyến khích) đọc và kiểm tra từng dòng code trước khi bấm chạy.</li>
    <li>👑 <b>Toàn quyền làm chủ (Total Ownership):</b> Bạn chạy website gì, nội dung ra sao, lưu lượng thế nào... tác giả hoàn toàn không biết và không thể biết. Bạn là người cầm 100% chìa khóa, toàn quyền quyết định việc sử dụng, triển khai và kinh doanh trên máy chủ của chính mình.</li>
</ul>

<hr>

<h2>⚠️ Tuyên Bố Miễn Trừ Trách Nhiệm & Tinh Thần Mã Nguồn Mở (Disclaimer)</h2>
<p>WPTangToc OLS là một dự án mã nguồn mở (Open Source) được chia sẻ hoàn toàn miễn phí vì cộng đồng. Chúng mình xây dựng phần mềm này với tất cả tâm huyết nhằm mang lại giá trị thực tế, tuy nhiên việc sử dụng phần mềm tuân theo các nguyên tắc cốt lõi của hệ sinh thái mã nguồn mở:</p>
<ul>
    <li><b>Bản chất Có sao dùng vậy:</b> Phần mềm được cung cấp nguyên trạng mà không đi kèm với bất kỳ bảo hành hay cam kết tuyệt đối nào. Sự đa dạng cực lớn về môi trường hạ tầng (nhà cung cấp VPS, phiên bản hệ điều hành, cấu hình mạng riêng...) có thể tạo ra các tình huống ngoại lệ nằm ngoài khả năng dự tính của phần mềm.</li>
    <li><b>Sự minh bạch & Quyền tự chủ:</b> Toàn bộ mã nguồn đều được công khai. Bạn có quyền (và được khuyến khích) kiểm tra mã nguồn trước khi thực thi. Do đó, bạn là người làm chủ 100% hệ thống của mình. Tác giả và những người đóng góp sẽ <b>miễn trừ mọi trách nhiệm pháp lý</b> đối với bất kỳ rủi ro nào liên quan đến gián đoạn dịch vụ, xung đột hệ thống, mất mát dữ liệu hay thiệt hại kinh tế phát sinh trực tiếp hoặc gián tiếp từ việc sử dụng phần mềm.</li>
    <li><b>Quy tắc vàng của System Admin:</b> Dữ liệu là tài sản vô giá của bạn. Dù công cụ đã được kiểm thử khắt khe đến đâu, "cẩn tắc vô áy náy". Chúng tôi đặc biệt yêu cầu bạn <b>luôn chủ động tạo Bản sao lưu (Snapshots/Backup)</b> toàn bộ dữ liệu máy chủ trước khi bắt đầu cài đặt, nâng cấp, hoặc gỡ bỏ bất kỳ thành phần nào.</li>
</ul>
<p><i>Bằng việc chạy các tập lệnh của WPTangToc OLS, bạn đồng ý với tinh thần chia sẻ của cộng đồng mã nguồn mở, thấu hiểu các rủi ro kỹ thuật hiện hữu và tự chịu trách nhiệm hoàn toàn đối với máy chủ cũng như dữ liệu của chính mình.</i></p>

<h2>⚖️ Bản quyền (License)</h2>
<p><b>GPLv3</b></p>
<p>Đây là dự án cống hiến cho cộng đồng mã nguồn mở (đặc biệt là cộng đồng System Admin tại Việt Nam). Bạn hoàn toàn có quyền sử dụng, phân phối lại hoặc sửa đổi nó theo các điều khoản của Giấy phép Công cộng GNU (GPLv3) tiêu chuẩn quốc tế, với hy vọng rằng nó sẽ giúp ích và làm cho môi trường web trở nên tốt đẹp hơn.</p>

